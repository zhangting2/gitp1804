from distutils.core import setup

setup(name="zz", version="1.0", description='this is test mod', author='zz', py_modules=['suba.aa', 'suba.bb', 'subb.cc', 'subb.dd'])
